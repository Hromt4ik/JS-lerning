export default [
  {
    name: 'Penang shrimp',
    price: 16,
    image: 'penang_shrimp.png',
    id: 'penang-shrimp'
  },
  {
    name: 'Chicken cashew',
    price: 14,
    image: 'chicken_cashew.png',
    id: 'chicken-cashew'
  },
  {
    name: 'Red curry veggies',
    price: 12.5,
    image: 'red_curry_vega.png',
    id: 'red-curry-veggies'
  },
  {
    name: 'Chicken springrolls',
    price: 6.5,
    image: 'chicken_loempias.png',
    id: 'chicken-springrolls'
  }
];
